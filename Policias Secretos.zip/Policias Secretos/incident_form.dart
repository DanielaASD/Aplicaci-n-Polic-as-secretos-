import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/incident_model.dart';
import '../providers/incident_provider.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:audioplayers/audioplayers.dart';

class IncidentForm extends StatefulWidget {
  @override
  _IncidentFormState createState() => _IncidentFormState();
}

class _IncidentFormState extends State<IncidentForm> {
  final _formKey = GlobalKey<FormState>();
  String _title = '';
  String _description = '';
  File? _photo;
  File? _audio;
  final ImagePicker _picker = ImagePicker();
  final AudioPlayer _audioPlayer = AudioPlayer();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _photo = File(pickedFile.path);
      });
    }
  }

  Future<void> _pickAudio() async {
    // Implement your audio picker logic here
  }

  Future<void> _saveIncident() async {
    if (_formKey.currentState!.validate() && _photo != null && _audio != null) {
      _formKey.currentState!.save();
      final appDir = await getApplicationDocumentsDirectory();
      final photoFileName = path.basename(_photo!.path);
      final savedPhoto = await _photo!.copy('${appDir.path}/$photoFileName');
      // Do the same for the audio file

      final newIncident = Incident(
        title: _title,
        date: DateTime.now(),
        description: _description,
        photoPath: savedPhoto.path,
        audioPath: _audio!.path, // Adjust this line to save the audio file path
      );

      Provider.of<IncidentProvider>(context, listen: false).addIncident(newIncident);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Registrar Incidencia')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Título'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingrese un título';
                  }
                  return null;
                },
                onSaved: (value) {
                  _title = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Descripción'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingrese una descripción';
                  }
                  return null;
                },
                onSaved: (value) {
                  _description = value!;
                },
              ),
              SizedBox(height: 10),
              _photo == null
                  ? Text('No se ha seleccionado foto')
                  : Image.file(_photo!),
              ElevatedButton(
                onPressed: _pickImage,
                child: Text('Tomar Foto'),
              ),
              SizedBox(height: 10),
              _audio == null
                  ? Text('No se ha seleccionado audio')
                  : Text('Audio seleccionado'),
              ElevatedButton(
                onPressed: _pickAudio,
                child: Text('Grabar Audio'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveIncident,
                child: Text('Guardar Incidencia'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}