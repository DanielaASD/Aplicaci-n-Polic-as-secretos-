import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/incident_model.dart';

class IncidentProvider with ChangeNotifier {
  List<Incident> _incidents = [];

  List<Incident> get incidents => _incidents;

  Future<void> addIncident(Incident incident) async {
    _incidents.add(incident);
    notifyListeners();
    await _saveIncidentsToPrefs();
  }

  Future<void> deleteAllIncidents() async {
    _incidents.clear();
    notifyListeners();
    await _saveIncidentsToPrefs();
  }

  Future<void> loadIncidentsFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final incidentsString = prefs.getString('incidents');
    if (incidentsString != null) {
      _incidents = (json.decode(incidentsString) as List)
          .map((incidentMap) => Incident.fromMap(incidentMap))
          .toList();
      notifyListeners();
    }
  }

  Future<void> _saveIncidentsToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final incidentsString = json.encode(_incidents.map((incident) => incident.toMap()).toList());
    await prefs.setString('incidents', incidentsString);
  }
}