import 'dart:io';
import 'package:flutter/material.dart';
import '../models/incident_model.dart';
import 'package:audioplayers/audioplayers.dart';

class IncidentDetail extends StatelessWidget {
  final Incident incident;

  IncidentDetail({required this.incident});

  @override
  Widget build(BuildContext context) {
    final AudioPlayer _audioPlayer = AudioPlayer();

   